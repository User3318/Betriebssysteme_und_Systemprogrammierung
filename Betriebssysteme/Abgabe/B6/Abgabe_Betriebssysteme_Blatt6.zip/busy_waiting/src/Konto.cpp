#include "Konto.h"

double Konto::getKontoStand() {
    return kontoStand;
}

void Konto::setKontoStand(double kontoStand) {
    this->kontoStand = kontoStand;
}
