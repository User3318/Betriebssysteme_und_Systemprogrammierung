/*! \file
 *  \brief Enthält die Klasse Assassin
 */

#pragma once

