#include "user/app2/testkappl.h"

#include "device/cga_stream.h"

extern CGA_Stream kout;

#include "syscall/guarded_keyboard.h"

extern Guarded_Keyboard keyboard;

#include "syscall/guarded_semaphore.h"

extern Guarded_Semaphore koutsem;

#include "syscall/guarded_bell.h"

#include "user/app2/World.h"

void TestKeyboardApplication::action() {

    kout << "###############################################################" << endl;
    kout << "################## Create Block: 1 Type X Y ###################" << endl;
    kout << "################# Type: 1 = Cube 2 = Pyramid ##################" << endl;
    kout << "##################### Move Block: 2 ID X Y ####################" << endl;
    kout << "###############################################################" << endl;

    /**
     * Die KeyboardApplication erlaubt Zugriff auf den aktuelle gedrückten Key
     * Zunächst ist zu überprüfen ob es sich um einen validen Key handelt.
     * Ist dies der Fall, soll der ASCII Wert (https://theasciicode.com.ar/extended-ascii-code/block-graphic-character-ascii-code-219.html)
     * des Keys augelesen werden in die richtige Zahl überführt werden, beispielsweise Drücken der 1 Taste liefert den Wert 49.
     * OOStubs unterstützt keinen Nummernblock. Daher sollten die normalen Nummerntasten verwednet werden!
     * Bei fehlerhaften Eingaben soll der Wert 3 für length und width angenommen werden.
     */

    int length = 2;
    int width = 2;

    kout << "Insert World length (1 digit): " << flush;
    kout << length << endl;

    kout << "Insert World width (1 digit): " << flush;
    kout << width << endl;


    World *world = new World(length, width);

    if (world->isRunning()) {
        handleInput(world);
    }

    delete world;

    while (true) {
    }
}

void TestKeyboardApplication::handleInput(World *world) const {

    kout << "Place CubeBlock to 1,1" << endl;
    if(world->handleKeyboardInput(1,1,1,1) == -1) {
        kout << "Misserfolg" << endl;
    } else {
        kout <<  "Erfolg" << endl;
    }

    kout << "Place second CubeBlock to 1,1" << endl;
    if(world->handleKeyboardInput(1,1,1,1) == -1) {
        kout << "Misserfolg" << endl;
    } else {
        kout << "Erfolg" << endl;
    }

    kout << "Place PyramideBlock to 0,0" << endl;
    int pId = world->handleKeyboardInput(1, 2, 0, 0);
    if(pId == -1) {
        kout << "Misserfolg" << endl;
    } else {
        kout << "Erfolg" << endl;
    }

    kout << "Place CubeBlock to 0,0" << endl;
    if(world->handleKeyboardInput(1,1,0,0) == -1) {
        kout << "Misserfolg" << endl;
    } else {
        kout << "Erfolg" << endl;
    }

    kout << "Move PyramidBlock to 0,1" << endl;
    if(world->handleKeyboardInput(2,pId,0,1) == -1) {
        kout << "Misserfolg" << endl;
    } else {
        kout << "Erfolg" << endl;
    }

    kout << "Place three CubeBlocks to 1,0" << endl;
    bool success = true;
    for(int i = 0; i<3 ; i++) {
        if(world->handleKeyboardInput(1,1,1,0) == -1) {
            success = false;
        }
    }
    if(success) {
        kout << "Erfolg" << endl;
    } else {
        kout << "Misserfolg" << endl;
    }

    world->printField();
}
